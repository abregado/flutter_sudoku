package com.example.flutter_sudoku

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
